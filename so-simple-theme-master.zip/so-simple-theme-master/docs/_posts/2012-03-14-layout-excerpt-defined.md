---
title: "Layout: Excerpt (Defined)"
excerpt: "This is a user-defined post excerpt. It should be displayed in place of the auto-generated excerpt  or post content on index pages."
categories:
  - Layout
  - Uncategorized
tags:
  - content
  - excerpt
  - layout
last_modified_at: 2017-03-09T12:43:31-05:00
---

This is the start of the post content.

This paragraph should be absent from an index page where `post.excerpt` is shown.